// src/app/anime/[slug]/page.tsx
export const dynamic = "force-dynamic";
export const revalidate = 120;

import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { auth } from "@/auth";
import { serverApi } from "@/lib/api";

import PlayerSection from "@/components/PlayerSection";
import BookmarkButton from "@/components/BookmarkButton";

import Background from "@/components/anime/detail/Background";
import Breadcrumbs from "@/components/anime/detail/Breadcrumbs";
import PosterCard from "@/components/anime/detail/PosterCard";
import InfoCard from "@/components/anime/detail/InfoCard";
import CreditsCard from "@/components/anime/detail/CreditsCard";
import RatingsCard from "@/components/anime/detail/RatingsCard";
import CommentsSection from "@/components/anime/detail/CommentsSection";

import type {
  MaterialDetail,
  Translation,
  MaterialVersion,
  Season,
  Episode,
  Country,
} from "@/types/DB/kodik";

/* ========= helpers ========= */
type PageProps = { params: { slug: string } };

function pickLinkFromEpisode(e?: Partial<Episode> | null): string | null {
  if (!e) return null;
  const c = [e.link, (e as any)?.iframe, (e as any)?.iframe_src, (e as any)?.url].find(
    (v) => typeof v === "string" && v.length
  );
  if (!c) return null;
  return (c as string).startsWith("//") ? "https:" + c : (c as string);
}

function normalizeVersions(m: MaterialDetail): MaterialVersion[] {
  if (Array.isArray(m.versions) && m.versions.length) {
    return m.versions.map((v) => {
      const translation: Translation =
        typeof v.translation === "object"
          ? (v.translation as Translation)
          : ({
              id: v.translation,
              ext_id: 0,
              title: "Озвучка",
              type: "voice",
              slug: "unknown",
              poster_url: "",
              avatar_url: "",
              banner_url: "",
              description: "",
              website_url: "",
              aliases: [],
              country: null,
              founded_year: null,
            } as any);
      return { ...v, translation };
    });
  }
  const seasons: Season[] = (m as any).seasons || [];
  if (Array.isArray(seasons) && seasons.length) {
    const original: Translation = {
      id: 0,
      ext_id: 0,
      title: "Оригинал",
      type: "voice",
      slug: "original",
      poster_url: "",
      avatar_url: "",
      banner_url: "",
      description: "",
      website_url: "",
      aliases: [],
      country: null,
      founded_year: null,
    };
    return [{ id: 0 as any, material: m.kodik_id, translation: original, movie_link: "", seasons }];
  }
  return [];
}

function firstLink(versions: MaterialVersion[]): string | null {
  for (const v of versions) {
    for (const s of (v as any).seasons || []) {
      for (const e of (s as any).episodes || []) {
        const l = pickLinkFromEpisode(e);
        if (l) return l;
      }
    }
  }
  return null;
}

/* ========= SEO / metadata ========= */
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  try {
    const api = await serverApi();
    const { data: m } = await api.get<MaterialDetail>(`/api/kodik/materials/${params.slug}/`);

    const poster =
      m.poster_url ||
      m.extra?.poster_url ||
      m.extra?.anime_poster_url ||
      m.extra?.drama_poster_url ||
      undefined;

    const title = m.title + (m.year ? ` (${m.year})` : "");
    const description =
      m.extra?.description?.slice(0, 180) ||
      `${m.title_orig ? m.title_orig + " — " : ""}${(m.genres || [])
        .slice(0, 3)
        .map((g) => g.name)
        .join(", ")}`;

    return {
      title,
      description,
      openGraph: {
        title,
        description,
        images: poster ? [{ url: poster }] : undefined,
        type: "video.other",
      },
      twitter: {
        card: "summary_large_image",
        title,
        description,
        images: poster ? [poster] : undefined,
      },
    };
  } catch {
    return {};
  }
}

/* ========= PAGE (server component) ========= */
export default async function AnimeDetailPage({ params }: PageProps) {
  const api = await serverApi();
  const { slug } = params;

  let m: MaterialDetail;
  try {
    const resp = await api.get<MaterialDetail>(`/api/kodik/materials/${slug}/`);
    m = resp.data;
  } catch (e: any) {
    if (e?.response?.status === 404) notFound();
    throw e;
  }

  // статус пользователя (если авторизован)
  type MyEntry = { id: number; status: string; material?: { slug?: string } };
  let myStatus: string | null = null;
  try {
    const me = await api.get<{ results: MyEntry[] }>(`/api/users/me/anime/`, {
      params: { search: m.slug, page_size: 1 },
    });
    const item = (me.data?.results || []).find((r) => r.material?.slug === m.slug);
    myStatus = item?.status ?? null;
  } catch {
    myStatus = null;
  }

  const poster =
    m.poster_url ||
    m.extra?.poster_url ||
    m.extra?.anime_poster_url ||
    m.extra?.drama_poster_url ||
    null;

  const versions = normalizeVersions(m);
  const initialLink = firstLink(versions) || "";

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": m.type === "anime-serial" ? "TVSeries" : "CreativeWork",
    name: m.title,
    inLanguage: "ru",
    datePublished: m.year ? `${m.year}-01-01` : undefined,
    image: poster || undefined,
    genre: (m.genres || []).map((g) => g.name),
    countryOfOrigin: (m.production_countries || [])
      .map((c) => (typeof c === "object" && c ? (c as Country).name : null))
      .filter(Boolean),
  };

  // сессия пользователя (для меню ред/удалить в комментариях)
  const session = await auth();
  const currentUserId = (session as any)?.user?.id ?? null;
  const isStaff =
    (session as any)?.user?.is_staff === true ||
    (session as any)?.user?.role === "staff" ||
    (session as any)?.user?.isAdmin === true;

  return (
    <main className="relative min-h-screen bg-transparent text-[var(--foreground)] selection:bg-[color:var(--accent)/0.3]">
      <script
        type="application/ld+json"
        suppressHydrationWarning
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <Background poster={poster} title={m.title} />
      <div className="relative z-10 mx-auto max-w-7xl px-4 md:px-6 pt-[8vh] md:pt-[10vh] pb-10">
        <Breadcrumbs title={m.title} />

        <section
          className="
            relative z-10
            grid grid-cols-1 gap-6 items-start
            md:flex md:items-start md:gap-6
            -mt-[12vh] md:-mt-[35vh]
          "
        >
          <PosterCard
            poster={poster}
            title={m.title}
            link={m.link || `https://kodik.cc`}
            actions={<BookmarkButton slug={m.slug} initialStatus={myStatus} />}
          />

          <div className="space-y-4 md:flex-1">
            <InfoCard data={m} />
            <CreditsCard credits={m.credits} />
          </div>

          <RatingsCard
            kp={m.extra?.kinopoisk_rating}
            imdb={m.extra?.imdb_rating}
            shiki={m.extra?.shikimori_rating}
            mdl={m.extra?.mydramalist_rating}
            aki={(m.extra as any)?.aki_rating ?? null}
            akiVotes={(m.extra as any)?.aki_votes ?? null}
            updatedAt={m.updated_at}
            total={m.extra?.episodes_total ?? null}
            aired={m.extra?.episodes_aired ?? null}
            status={(m.extra?.anime_status ?? m.extra?.all_status ?? "").toLowerCase()}
          />
        </section>

        {/* Комментарии — сразу после плеера */}
        <section id="comments" className="mt-6">
          {/* ВАЖНО: в API комментариев materialId = kodik_id */}
          <CommentsSection
            materialId={m.kodik_id}
            currentUserId={currentUserId ?? undefined}
            isStaff={!!isStaff}
          />
        </section>

        <footer className="py-8 text-center text-[color:var(--foreground)/0.4] text-xs">
          Обновлено: {new Date(m.updated_at).toLocaleDateString()}
        </footer>
      </div>
    </main>
  );
}
