import { serverApi } from "@/lib/api";
import type { MangaLite } from "@/types/manga";
import { MangaGrid } from "@/components/manga";

type Paginated<T> = { count: number; next: string | null; previous: string | null; results: T[] };
export const revalidate = 120;

function getQ(searchParams: Record<string, string | string[] | undefined>, key: string) {
  const v = searchParams[key];
  if (!v) return undefined;
  return Array.isArray(v) ? v[0] : v;
}

async function fetchList(params: Record<string, any>) {
  const api = await serverApi();
  const { data } = await api.get<Paginated<MangaLite> | MangaLite[]>("/api/manga/", { params });
  if (Array.isArray(data)) return { items: data, total: data.length };
  return { items: data?.results ?? [], total: data?.count ?? 0 };
}

export default async function MangaCatalogPage({ searchParams }: { searchParams: Record<string, string | string[] | undefined> }) {
  const page = 1;
  const page_size = 30;

  const baseQuery: Record<string, string | number | undefined> = {
    q: getQ(searchParams, "q"),
    type: getQ(searchParams, "type"),
    year: getQ(searchParams, "year"),
    genre: getQ(searchParams, "genre"),
    category: getQ(searchParams, "category"),
    work_status: getQ(searchParams, "work_status"),
    ordering: getQ(searchParams, "ordering") ?? "-updated_at",
  };

  const { items, total } = await fetchList({ page, page_size, ...baseQuery });

  return (
    <main className="min-h-screen bg-slate-950 text-white selection:bg-indigo-500/30">
      <div className="mx-auto max-w-7xl px-4 md:px-6 py-8 md:py-10">
        <div className="mb-2 flex items-center justify-between">
          <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight">Манга</h1>
          <span className="hidden sm:inline-flex items-center rounded-full border border-white/15 bg-white/8 px-2.5 py-1 text-xs">
            Сортировка: новые → обновлённые
          </span>
        </div>

        <MangaGrid
          initialItems={items}
          total={total}
          pageSize={page_size}
          baseQuery={baseQuery}
          fetchPath="/api/manga"
        />
      </div>
    </main>
  );
}
