"use server";

import { auth } from "@/auth";
import { apiBase } from "@/lib/api";

/** Базовый URL без хвоста "/" */
function apiUrl(path: string) {
  return `${(apiBase || "").replace(/\/+$/, "")}${path}`;
}

/** Готовим заголовки авторизации из NextAuth-сессии */
async function getAuthHeaders(): Promise<HeadersInit> {
  let s: any = null;
  try {
    s = await auth();
  } catch {
    // нет сессии — оставим пусто
  }

  const token =
    s?.access ||
    s?.user?.access ||
    s?.user?.token ||
    s?.user?.backendToken ||
    s?.backendToken;

  const headers: Record<string, string> = {};
  if (token) {
    headers.Authorization = /^(Bearer|Token)\s/i.test(token)
      ? token
      : `Bearer ${token}`;
  }
  return headers;
}

/** СОЗДАТЬ ГЛАВУ (multipart, без ручного Content-Type) */
export async function createChapterAction(payload: {
  edition: number | string;
  number: string;
  name?: string;
  volume?: number;
  published_at?: string;
}) {
  const headers = await getAuthHeaders();

  const fd = new FormData();
  for (const [k, v] of Object.entries(payload)) {
    if (v !== undefined && v !== null) fd.append(k, String(v));
  }

  const res = await fetch(apiUrl("/api/chapters/"), {
    method: "POST",
    headers,
    body: fd,
  });

  const txt = await res.text();
  if (!res.ok) throw new Error(`Create chapter failed: ${res.status} ${txt}`);
  try {
    return JSON.parse(txt) as { id: number | string };
  } catch {
    throw new Error(`Create chapter parse error: ${txt}`);
  }
}

/** ЗАГРУЗИТЬ СТРАНИЦЫ (просто прокидываем исходный FormData из <form>) */
export async function uploadChapterImagesAction(
  chapterId: number | string,
  form: FormData
) {
  const headers = await getAuthHeaders();

  const res = await fetch(apiUrl(`/api/chapters/${chapterId}/images/`), {
    method: "POST",
    headers,
    body: form,
  });

  const txt = await res.text();
  if (!res.ok) throw new Error(`Upload images failed: ${res.status} ${txt}`);
  try {
    return JSON.parse(txt);
  } catch {
    return { ok: true };
  }
}

/** ЗАГРУЗИТЬ ZIP/CBZ (ключ поля из формы — name="zip"; бэкенд принимает file|zip|archive) */
export async function uploadChapterZipAction(
  chapterId: number | string,
  form: FormData
) {
  const headers = await getAuthHeaders();

  const res = await fetch(apiUrl(`/api/chapters/${chapterId}/images-zip/`), {
    method: "POST",
    headers,
    body: form,
  });

  const txt = await res.text();
  if (!res.ok) throw new Error(`Upload zip failed: ${res.status} ${txt}`);
  try {
    return JSON.parse(txt);
  } catch {
    return { ok: true };
  }
}
