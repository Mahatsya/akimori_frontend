import Link from "next/link";
import ChapterUploader from "./ChapterUploader";

type Chapter = {
  id: number | string;
  number: string;
  name?: string | null;
  pages_count?: number | null;
  published_at?: string | null;
};

type Edition = {
  id: number | string;
  translation_status?: string;
  translator?: { name: string; slug: string };
  chapters?: Chapter[];
};

export default function EditionSection({
  editions,
  mangaSlug,
  currentUserId,
}: {
  editions: Edition[];
  mangaSlug: string;
  currentUserId?: string | number;
}) {
  if (!editions?.length) return null;

  return (
    <div className="mt-6 space-y-6">
      {editions.map((ed) => {
        const chapters = [...(ed.chapters || [])].sort((a, b) => {
          const na = parseFloat(String(a.number).replace(",", "."));
          const nb = parseFloat(String(b.number).replace(",", "."));
          if (Number.isFinite(na) && Number.isFinite(nb) && na !== nb) return nb - na;
          return String(b.number).localeCompare(String(a.number), undefined, { numeric: true });
        });

        return (
          <section key={String(ed.id)} className="rounded-2xl border border-white/12 bg-white/6 p-4">
            <div className="mb-3">
              <div className="text-sm text-white/60">Переводчик</div>
              <div className="text-lg font-semibold truncate">{ed.translator?.name || "—"}</div>
              {ed.translation_status ? (
                <div className="mt-1 text-xs text-white/60">Статус перевода: {ed.translation_status}</div>
              ) : null}
            </div>

            {chapters.length ? (
              <ul className="divide-y divide-white/10 rounded-xl border border-white/10 bg-white/5">
                {chapters.map((ch) => (
                  <li key={String(ch.id)} className="p-3 md:p-4">
                    <Link
                      href={`/manga/${mangaSlug}/chapter/${ch.id}`}
                      className="flex items-center justify-between gap-3 hover:opacity-100"
                    >
                      <div className="min-w-0">
                        <div className="font-medium">
                          Глава {ch.number}{ch.name ? <span className="text-white/70"> — {ch.name}</span> : null}
                        </div>
                        <div className="text-xs text-white/60">
                          {ch.pages_count ? `${ch.pages_count} стр.` : "без страниц"}
                          {ch.published_at ? ` • ${new Date(ch.published_at).toLocaleDateString()}` : ""}
                        </div>
                      </div>
                      <span className="shrink-0 text-xs rounded-md border border-white/10 bg-white/5 px-2 py-0.5">
                        читать →
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <div className="text-sm text-white/70">Пока нет глав.</div>
            )}

            <ChapterUploader editionId={ed.id} />
          </section>
        );
      })}
    </div>
  );
}
