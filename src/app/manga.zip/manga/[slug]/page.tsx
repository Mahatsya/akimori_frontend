import { notFound } from "next/navigation";
import Image from "next/image";
import Link from "next/link";
import { serverApi } from "@/lib/api";
import type { MangaDetail } from "@/types/manga";
import { AgeBadge, TypeBadge, WorkStatusBadge } from "@/components/manga";
import EditionTabs from "@/components/manga/EditionTabs";
import EditionSection from "@/components/manga/EditionSection";

export const revalidate = 60;

async function fetchManga(slug: string): Promise<MangaDetail | null> {
  const api = await serverApi();
  try {
    const { data } = await api.get<MangaDetail>(`/api/manga/${slug}/full/`);
    return data;
  } catch {
    return null;
  }
}

async function getSessionUserId(): Promise<string | number | undefined> {
  try {
    const { auth } = await import("@/auth");
    const session = await auth();
    return (session as any)?.user?.id ?? (session as any)?.user?.pk ?? (session as any)?.user?.sub;
  } catch {
    return undefined;
  }
}

export default async function MangaPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [manga, currentUserId] = await Promise.all([fetchManga(slug), getSessionUserId()]);
  if (!manga) return notFound();

  const stats = {
    views: manga.meta?.views ?? 0,
    likes: manga.meta?.likes ?? 0,
    bookmarks: manga.meta?.bookmarks ?? 0,
    rating: manga.rating?.value ?? null,
  };

  return (
    <main className="min-h-screen bg-slate-950 text-white selection:bg-indigo-500/30">
      {/* ====== HERO / POSTER ====== */}
      <section className="relative w-full">
        {manga.banner_url ? (
          <div className="relative h-48 md:h-64 lg:h-72 w-full overflow-hidden">
            <Image
              src={manga.banner_url}
              alt=""
              fill
              className="object-cover opacity-60"
              unoptimized
              priority
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
          </div>
        ) : (
          <div className="h-32 md:h-48 bg-gradient-to-b from-slate-900 to-slate-950" />
        )}
      </section>

      {/* ====== MAIN CARD ====== */}
      <section className="relative -mt-12 md:-mt-16 mx-auto max-w-7xl px-4 md:px-6">
        <div className="relative z-10 rounded-3xl border border-white/10 bg-white/6 backdrop-blur-xl shadow-[0_10px_40px_-15px_rgba(0,0,0,.7)] p-4 md:p-6">
          <div className="grid grid-cols-1 lg:grid-cols-[260px,1fr,280px] gap-6">
            
            {/* === LEFT: Poster + actions === */}
            <aside>
              <div className="relative w-full aspect-[3/4] rounded-2xl overflow-hidden border border-white/10 bg-black/30 shadow-xl">
                {manga.poster_url && (
                  <Image
                    src={manga.poster_url}
                    alt={manga.title_ru}
                    fill
                    className="object-cover"
                    unoptimized
                  />
                )}
              </div>

              <div className="mt-4 space-y-3">
                <Link
                  href={`/manga/${slug}/read`}
                  className="block text-center rounded-2xl bg-indigo-500 hover:bg-indigo-400 active:bg-indigo-600 transition-colors px-4 py-3 font-semibold"
                >
                  Читать
                </Link>

                <button className="w-full rounded-2xl bg-white/10 hover:bg-white/15 border border-white/10 px-4 py-3 font-semibold">
                  В закладки
                </button>

                <div className="text-xs text-white/70 pt-2 space-y-1">
                  <p>Просмотры: {stats.views.toLocaleString()}</p>
                  <p>Лайки: {stats.likes.toLocaleString()}</p>
                  <p>Закладки: {stats.bookmarks.toLocaleString()}</p>
                </div>
              </div>
            </aside>

            {/* === CENTER: Info + Description + Editions === */}
            <section className="min-w-0">
              <header>
                <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight">
                  {manga.title_ru}
                </h1>
                {manga.title_en && (
                  <p className="text-white/70">{manga.title_en}</p>
                )}
                {manga.alt_titles?.length ? (
                  <p className="mt-1 text-xs text-white/60 line-clamp-2">
                    {manga.alt_titles.join(" • ")}
                  </p>
                ) : null}

                <div className="mt-3 flex flex-wrap gap-2">
                  <TypeBadge value={manga.type} />
                  <AgeBadge value={manga.age_rating} />
                  <WorkStatusBadge value={manga.work_status} />
                  {manga.year && (
                    <span className="px-2 py-0.5 rounded-md bg-black/50 border border-white/10 text-[11px]">
                      {manga.year}
                    </span>
                  )}
                </div>
              </header>

              {/* Genres & Categories */}
              <div className="mt-3 flex flex-wrap gap-2 text-[11px]">
                {manga.categories?.map((c) => (
                  <span key={c.slug} className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5">
                    {c.title}
                  </span>
                ))}
                {manga.genres?.map((g) => (
                  <span key={g.slug} className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5">
                    {g.title}
                  </span>
                ))}
              </div>

              {/* Description */}
              {manga.description && (
                <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-4">
                  <h3 className="text-sm font-semibold text-white/80 mb-2">Описание</h3>
                  <p className="text-white/85 leading-relaxed">{manga.description}</p>
                </div>
              )}

              {/* Publishers / Creators */}
              {(manga.publishers?.length || manga.creators?.length) && (
                <div className="mt-5 grid grid-cols-1 md:grid-cols-2 gap-4">
                  {manga.publishers?.length ? (
                    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                      <h3 className="text-sm font-semibold text-white/80 mb-2">Паблишеры</h3>
                      <div className="flex flex-wrap gap-2 text-[11px]">
                        {manga.publishers.map((p, i) => (
                          <span key={i} className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5">
                            {p.title || p.name || String(p)}
                          </span>
                        ))}
                      </div>
                    </div>
                  ) : null}
                  {manga.creators?.length ? (
                    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                      <h3 className="text-sm font-semibold text-white/80 mb-2">Создатели</h3>
                      <div className="flex flex-wrap gap-2 text-[11px]">
                        {manga.creators.map((c, i) => (
                          <span key={i} className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5">
                            {c.title || c.name || String(c)}
                          </span>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </div>
              )}

              {/* Editions & Chapters */}
              <div className="mt-8">
                <EditionTabs
                  editions={manga.editions || []}
                  renderBelow={(current) => (
                    <EditionSection
                      editions={[current]}
                      mangaSlug={slug}
                      currentUserId={currentUserId}
                    />
                  )}
                />
              </div>
            </section>

            {/* === RIGHT: Rating + Similar === */}
            <aside className="space-y-4">
              <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <h3 className="text-sm font-semibold text-white/80 mb-1">Рейтинг</h3>
                <div className="text-4xl font-extrabold">
                  {stats.rating ? stats.rating.toFixed(1) : "—"}
                </div>
                {manga.rating?.votes ? (
                  <div className="text-xs text-white/60 mt-1">
                    {manga.rating.votes} голосов
                  </div>
                ) : null}
              </div>

              {manga.similar?.length ? (
                <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
                  <h3 className="text-sm font-semibold text-white/80 mb-2">Похожее</h3>
                  <ul className="space-y-3">
                    {manga.similar.slice(0, 6).map((s, i) => (
                      <li key={i} className="flex items-center gap-3">
                        <div className="relative h-14 w-10 rounded-md overflow-hidden border border-white/10 bg-white/5">
                          {s.poster_url && (
                            <Image
                              src={s.poster_url}
                              alt={s.title_ru || s.title_en || "similar"}
                              fill
                              className="object-cover"
                              unoptimized
                            />
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <Link
                            href={`/manga/${s.slug}`}
                            className="block truncate hover:underline"
                          >
                            {s.title_ru || s.title_en}
                          </Link>
                          <div className="text-xs text-white/60 truncate">
                            {s.reason || "Похож по жанрам"}
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </aside>
          </div>
        </div>
      </section>
    </main>
  );
}
