"use client";

import { useCallback, useState, useTransition } from "react";
import { createChapterAction } from "./actions";

export default function ChapterUploader({
  editionId,
}: {
  editionId: number | string;
}) {
  const [error, setError] = useState<string | null>(null);
  const [createdId, setCreatedId] = useState<number | string | null>(null);
  const [isPending, startTransition] = useTransition();

  // СОЗДАТЬ ГЛАВУ — server action (небольшой запрос)
  const onCreate = useCallback((e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);

    const fd = new FormData(e.currentTarget);
    const number = String(fd.get("number") || "").trim();
    const name = String(fd.get("name") || "").trim();
    const volume = String(fd.get("volume") || "").trim();
    const publishedAt = String(fd.get("published_at") || "");

    if (!number) return setError("Укажите номер главы.");

    startTransition(async () => {
      try {
        const ch = await createChapterAction({
          edition: editionId,
          number,
          name: name || undefined,
          volume: volume ? Number(volume) : undefined,
          published_at: publishedAt ? new Date(publishedAt).toISOString() : undefined,
        });
        setCreatedId(ch.id);
      } catch (e: any) {
        setError(e?.message ?? "Ошибка создания главы");
      }
    });
  }, [editionId]);

  return (
    <div className="mt-6 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4">
      <h3 className="text-lg font-bold">Добавить главу</h3>

      {/* Создать главу */}
      <form onSubmit={onCreate} className="mt-3 grid grid-cols-1 md:grid-cols-5 gap-3">
        <label className="flex flex-col gap-1">
          <span className="text-xs text-white/70">Номер главы *</span>
          <input name="number" required placeholder="1, 12.5, 100"
                 className="rounded-lg bg-white/10 border border-white/15 px-3 py-2 text-sm"/>
        </label>
        <label className="flex flex-col gap-1">
          <span className="text-xs text-white/70">Название</span>
          <input name="name" className="rounded-lg bg-white/10 border border-white/15 px-3 py-2 text-sm"/>
        </label>
        <label className="flex flex-col gap-1">
          <span className="text-xs text-white/70">Том</span>
          <input name="volume" type="number" min={1}
                 className="rounded-lg bg-white/10 border border-white/15 px-3 py-2 text-sm"/>
        </label>
        <label className="flex flex-col gap-1">
          <span className="text-xs text-white/70">Дата публикации</span>
          <input name="published_at" type="datetime-local"
                 defaultValue={new Date().toISOString().slice(0,16)}
                 className="rounded-lg bg-white/10 border border-white/15 px-3 py-2 text-sm"/>
        </label>
        <div className="flex items-end">
          <button type="submit" disabled={isPending}
                  className="inline-flex items-center justify-center rounded-lg border border-emerald-500/50 bg-emerald-500/20 px-4 py-2 text-sm hover:bg-emerald-500/30">
            {isPending ? "Создаю…" : "Создать главу"}
          </button>
        </div>
      </form>

      {/* Загрузки доступны после создания */}
      {createdId && (
        <div className="mt-4 grid gap-4 md:grid-cols-2">
          {/* 1) Файлы — напрямую в прокси-роут */}
          <form
            action={`/api/proxy/chapters/${createdId}/images`}
            method="post"
            encType="multipart/form-data"
            className="rounded-xl border border-white/10 bg-white/5 p-3"
          >
            <div className="text-sm font-semibold">Загрузить страницы (файлы)</div>
            <p className="text-xs text-white/60">JPG, PNG, WEBP. Можно несколько.</p>
            <input
              className="mt-2 block w-full text-sm"
              type="file"
              name="files"
              multiple
              required
              accept=".jpg,.jpeg,.png,.webp"
            />
            <button className="mt-2 rounded-lg border border-white/15 bg-white/10 px-3 py-2 text-sm hover:bg-white/15">
              Загрузить файлы
            </button>
          </form>

          {/* 2) ZIP/CBZ — тоже в прокси-роут. Ключ 'file' — бэкенду так удобнее */}
          <form
            action={`/api/proxy/chapters/${createdId}/images-zip`}
            method="post"
            encType="multipart/form-data"
            className="rounded-xl border border-white/10 bg-white/5 p-3"
          >
            <div className="text-sm font-semibold">Загрузить ZIP/CBZ</div>
            <p className="text-xs text-white/60">Внутри — только .jpg/.jpeg/.png/.webp.</p>
            <input
              className="mt-2 block w-full text-sm"
              type="file"
              name="file"
              accept=".zip,.cbz"
              required
            />
            <button className="mt-2 rounded-lg border border-white/15 bg-white/10 px-3 py-2 text-sm hover:bg-white/15">
              Загрузить ZIP
            </button>
          </form>
        </div>
      )}

      {error && <p className="mt-3 text-xs text-red-300">{error}</p>}
    </div>
  );
}
