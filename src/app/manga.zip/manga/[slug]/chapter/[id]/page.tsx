import { notFound } from "next/navigation";
import { serverApi } from "@/lib/api";
import ChapterReader from "@/components/reader/ChapterReader";
import type { ChapterDetail } from "@/types/chapter";

export const revalidate = 60;

async function fetchChapter(id: string): Promise<ChapterDetail | null> {
  const api = await serverApi();
  try {
    const { data } = await api.get<ChapterDetail>(`/api/chapters/${id}/`);
    return data;
  } catch {
    return null;
  }
}

function normalizePages(ch?: ChapterDetail) {
  const raw: any[] = (ch as any)?.pages || (ch as any)?.images || (ch as any)?.chapter_pages || [];
  return raw
    .map((p) => ({
      id: p.id ?? `${p.order}-${p.image ?? p.image_url ?? p.url}`,
      order: Number(p.order ?? 0),
      url: String(p.image ?? p.image_url ?? p.url ?? ""),
    }))
    .filter((p) => !!p.url)
    .sort((a, b) => (a.order && b.order && a.order !== b.order)
      ? a.order - b.order
      : a.url.localeCompare(b.url, undefined, { numeric: true }));
}

// В Next 15 params — Promise. Ждём его.
export default async function ChapterPage({
  params,
}: {
  params: Promise<{ slug: string; id: string }>;
}) {
  const { id } = await params;

  const chapter = await fetchChapter(id);
  if (!chapter) return notFound();

  const pages = normalizePages(chapter);
  const title = `Глава ${chapter.number}${chapter.name ? ` — ${chapter.name}` : ""}`;

  return <ChapterReader title={title} pages={pages} />;
}
