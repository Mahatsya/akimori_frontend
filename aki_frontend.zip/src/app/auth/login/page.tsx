export const dynamic = "force-dynamic";
export const revalidate = 0;

import LoginPageClient from "./LoginPageClient";

export default function LoginPage() {
  return <LoginPageClient />;
}
