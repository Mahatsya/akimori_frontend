// src/app/not-found.tsx

export const revalidate = 0;

import NotFoundClient from "@/components/NotFoundClient";

export default function NotFoundPage() {
  return <NotFoundClient />;
}
