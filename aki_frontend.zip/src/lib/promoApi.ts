// src/lib/promoApi.ts
export type PromoEffectType = "topup_discount" | "balance_bonus" | "item_grant" | "none";

export type PromoEffect = {
  type: PromoEffectType;
  data: Record<string, any>;
};

export type PromoOut = {
  code: string;
  is_active: boolean;
  starts_at: string;
  ends_at: string;
  max_total_uses: number;
  max_uses_per_user: number;
  uses_count: number;
  effect: PromoEffect;
};

export type PromoQuoteOut =
  | { ok: true; discount_minor: number; payable_minor: number }
  | { ok: true; bonus_minor: number }
  | { ok: true }
  | { ok: false; reason: string };

export type PromoRedeemOut = {
  ok: boolean;
  redeemed_at: string;
  payload: Record<string, any>;
  note?: string;
};

const API_BASE = (process.env.NEXT_PUBLIC_API_BASE || "http://127.0.0.1:8000")

// ВАЖНО: тут использую trailing slash, как у тебя в остальных эндпоинтах.
// Если на бэке сделаешь без слэша — просто убери "/" в константах ниже.
const P = {
  validate: "/api/promo/validate/",
  redeem: "/api/promo/redeem/",
  topupQuote: "/api/promo/topup/quote/",
  topupApply: "/api/promo/topup/apply/",
};

async function postJson<T>(path: string, access: string, body: any, signal?: AbortSignal): Promise<T> {
  const r = await fetch(`${API_BASE}${path}`, {
    method: "POST",
    cache: "no-store",
    signal,
    headers: {
      accept: "application/json",
      "content-type": "application/json",
      Authorization: `Bearer ${access}`,
    },
    body: JSON.stringify(body),
  });

  const text = await r.text().catch(() => "");
  let data: any = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = { detail: text || "Invalid response" };
  }

  if (!r.ok) {
    const msg = data?.detail || `HTTP ${r.status}`;
    throw new Error(msg);
  }

  return data as T;
}

export async function promoValidate(access: string, code: string, signal?: AbortSignal) {
  return postJson<PromoOut>(P.validate, access, { code }, signal);
}

export async function promoRedeem(access: string, code: string, topup_amount_minor?: number | null, signal?: AbortSignal) {
  return postJson<PromoRedeemOut>(P.redeem, access, { code, topup_amount_minor: topup_amount_minor ?? null }, signal);
}

export async function promoTopupQuote(access: string, code: string, amount_minor: number, signal?: AbortSignal) {
  return postJson<{ promo: PromoOut; quote: PromoQuoteOut }>(P.topupQuote, access, { code, amount_minor }, signal);
}

export async function promoTopupApply(access: string, code: string, amount_minor: number, signal?: AbortSignal) {
  return postJson<PromoRedeemOut>(P.topupApply, access, { code, amount_minor }, signal);
}
